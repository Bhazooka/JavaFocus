#ifndef PBMIMAGE_H_INCLUDED
#define PBMIMAGE_H_INCLUDED

#include"Image2D.h"

class PBMImage2D:public Image2D
{
private:


public:
    PBMImage2D(int intRows, int intCols, int intValue);
    string toString();

};

#endif // PBMIMAGE_H_INCLUDED
