#ifndef PGMIMAGE_H_INCLUDED
#define PGMIMAGE_H_INCLUDED
#include"Image2D.h"

class PGMImage2D:public Image2D
{
private:


public:
    PGMImage2D(int intRows, int intCols, int intValue);
    string toString();

};

#endif // PGMIMAGE_H_INCLUDED
