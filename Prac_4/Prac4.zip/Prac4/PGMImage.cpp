#include"PGMImage.h"

PGMImage2D::PGMImage2D(int intRows, int intCols, int intValue):Image2D()
{

}

string PGMImage2D::toString()
{   int intHold=0;
    stringstream strHold;

            strHold<<"P2"<<endl;
            strHold<<"# Prac4.pgm"<<endl;
            strHold<<intRows<<" "<<intCols<<endl;
            strHold<<15<<endl;
    for(int r=0;r<intRows;r++)
    {
        for(int c=0;c<intCols;c++)
        {
            intHold=pixels[r][c];
            strHold<<intHold<<" ";

        }
        strHold<<endl;
    }
    return strHold.str();
}
