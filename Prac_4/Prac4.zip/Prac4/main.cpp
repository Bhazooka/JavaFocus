#include <iostream>
#include "Image2D.h"
#include "PGMImage.h"
#include "PBMImage.h"


using namespace std;

void PrintImage(Image2D* objPrint);
int ConvertToInt(string strNum);

int main(int argc, char** argv)
{
    int intRows=ConvertToInt(argv[1]);
    int intCols=ConvertToInt(argv[2]);
    int intRandom=ConvertToInt(argv[3]);

    if(intRandom==0)
    {
        //0 for pgm
        PGMImage2D* img = new PGMImage2D(intRows,intCols,10);
        PrintImage(img);
    }
    else if(intRandom==1)
    {
        //1 for pbm
        PBMImage2D* img = new PBMImage2D(intRows,intCols,10);
        PrintImage(img);
    }

    return 0;
}

void PrintImage(Image2D* objPrint)
{
    cout<<objPrint->toString();
}
int ConvertToInt(string strNum)
{
    stringstream ss {strNum};
    int intNum;
    ss>>intNum;




    return intNum;

}
