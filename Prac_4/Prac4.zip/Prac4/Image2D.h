#ifndef IMAGE2D_H_INCLUDED
#define IMAGE2D_H_INCLUDED
#include <iostream>
#include <sstream>
using namespace std;
class Image2D{
protected:

  int** pixels;
  int intRows;
  int intCols;

public:
    Image2D();
    Image2D(int intRows, int intCols, int intInitial);
    Image2D(const Image2D& objOriginal);
    ~Image2D();
    int getRows();
    int getCols();
    int getPixel(int intRow, int intCol);
    void setPixel(int intRow, int intCol, int intValue);
    virtual string toString()=0;





};


#endif // IMAGE2D_H_INCLUDED
