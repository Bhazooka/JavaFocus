#include "Image2D.h"

Image2D::Image2D():Image2D(100,100,5)
{

}

Image2D::Image2D(int intRows, int intCols, int intInitial)
{
        this->intRows=intRows;
        this->intCols=intCols;

        pixels= new int*[intRows];

        for(int r=0; r<intRows;r++)
        {

        pixels[r]=new int[intCols];
        for(int c=0;c<intCols;c++)
        {
            pixels[r][c]=intInitial;
        }
        }
}

Image2D::Image2D(const Image2D& objOriginal)
{

        this->intRows=objOriginal.intRows;
        this->intCols=objOriginal.intCols;

        pixels= new int*[intRows];

        for(int r=0; r<intRows;r++)
        {

        pixels[r]=new int[intCols];
        for(int c=0;c<intCols;c++)
        {
            pixels[r][c]=objOriginal.pixels[r][c];
        }
        }
}

Image2D::~Image2D()
{
    delete [] pixels;

    for(int r=0;r<intRows;r++)
        delete pixels[r];

    pixels=nullptr;
}

int Image2D::getRows()
{
    return intRows;

}

int Image2D::getCols()
{
    return intCols;
}

void Image2D::setPixel(int intRow, int intCol, int intValue)
{   pixels[intRow][intCol]=intValue;

}

string Image2D::toString()
{
    return "";
}

int Image2D::getPixel(int intRow, int intCol)
{
    return pixels[intRow][intCol];
}

