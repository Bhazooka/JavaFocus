#include "PBMImage.h"


PBMImage2D::PBMImage2D(int intRows, int intCols, int intValue):Image2D()
{

}

string PBMImage2D::toString()
{
   int intHold=0;
    stringstream strHold;

            strHold<<"P1"<<endl;
            strHold<<"# Prac4.pbm"<<endl;
            strHold<<intRows<<" "<<intCols<<endl;
            strHold<<15<<endl;
    for(int r=0;r<intRows;r++)
    {
        for(int c=0;c<intCols;c++)
        {
            intHold=pixels[r][c];
            if(intHold>0)
            {
                intHold=1;
            }
            else if(intHold==0)
            {
                intHold=0;
            }
            strHold<<intHold<<" ";

        }
        strHold<<endl;
    }
    return strHold.str();
}
