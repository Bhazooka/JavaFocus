import server.ServerSide;

public class Main {

	public static void main(String[] args) {
		 
		ServerSide s = new ServerSide(4321);
		s.start();
	}

}
