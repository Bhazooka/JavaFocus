package csc2b.server;

public class Server
{
    public static void main(String[] argv)
    {
    	 new BUKAServer(2018);
    }

	
}
