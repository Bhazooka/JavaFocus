package csc2b.client;

public class BUKAClientPane extends GridPane //You may change the JavaFX pane layout
{
	
    public BUKAClientPane()
    {
	//Create client connection
	//Create buttons for each command
	//Use buttons to send commands
    	  	
    }
}
