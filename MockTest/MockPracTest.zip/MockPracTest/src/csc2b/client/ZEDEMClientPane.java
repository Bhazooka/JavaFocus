package csc2b.client;

import javafx.scene.layout.GridPane;

public class ZEDEMClientPane extends GridPane //You may change the JavaFX pane layout
{
	public ZEDEMClientPane() {
		
	}

}
