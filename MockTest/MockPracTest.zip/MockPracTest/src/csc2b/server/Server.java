package csc2b.server;

public class Server {

}
