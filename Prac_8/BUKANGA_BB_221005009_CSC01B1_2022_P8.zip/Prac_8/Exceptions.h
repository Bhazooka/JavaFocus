#ifndef EXCEPTIONS_H_INCLUDED
#define EXCEPTIONS_H_INCLUDED


class Exception{};
class RangeException : public Exception{};
class FileException : public Exception{};


#endif // EXCEPTIONS_H_INCLUDED
