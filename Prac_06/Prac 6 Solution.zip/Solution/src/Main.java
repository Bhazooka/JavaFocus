import acsse.csc2a.gui.MyPane;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author Mr D Ogwok
 * @version P06
 */
public class Main extends Application{

	/* TODO: JavaDoc */
	public static void main(String[] args) {
		launch(args);
	}

	/* TODO: JavaDoc */
	@Override
	public void start(Stage primaryStage) throws Exception {
		MyPane pane = new MyPane();
		// Scene
		Scene scene = new Scene(pane, 1500, 500);
		primaryStage.setTitle("Message Map");
		primaryStage.setScene(scene);
		// Show stage
		primaryStage.show();
	}

}
