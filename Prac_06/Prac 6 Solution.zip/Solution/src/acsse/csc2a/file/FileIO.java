package acsse.csc2a.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import acsse.csc2a.model.Planet;
import acsse.csc2a.model.SpaceShip;
import javafx.geometry.Point2D;
import javafx.scene.paint.Color;

/* TODO: JavaDoc */
public class FileIO {

	/* TODO: JavaDoc */
	public static ArrayList<SpaceShip> readSpaceShip(File filename){
		ArrayList<SpaceShip> ships = new ArrayList<SpaceShip>();
		Scanner sc = null;
		try {
			sc = new Scanner(filename);
			// File Format -> SpaceShip ID Name x y
			// Pattern for SpaceShip \d{1,4}\s\d{1,3}\s[A-Z]+\d{1}\s[A-Z][A-Za-z ]*
			final Pattern spaceShipPattern = Pattern.compile("\\d{1,4}\\s\\d{1,3}\\s[A-Z]+\\d{1}\\s[A-Z][A-Za-z ]*");
			// Ship to be processed/read from file 
			SpaceShip currentSpaceShip = null;
			// Read file
			while (sc.hasNextLine())
			{
				// Read the line
				String currentLine = sc.nextLine();
				// Create matchers from patterns to compare with
				Matcher spaceShipMatcher = spaceShipPattern.matcher(currentLine);
				// Test if pattern matches with matcher
				if(spaceShipMatcher.matches()) {
					StringTokenizer shipTokens = new StringTokenizer(currentLine, " ");
					int x = Integer.parseInt(shipTokens.nextToken());
					int y = Integer.parseInt(shipTokens.nextToken());
					String shipID = shipTokens.nextToken();
					String shipName = shipTokens.nextToken();
					while(shipTokens.hasMoreTokens()) {
						shipName += " " + shipTokens.nextToken();	
					}
					currentSpaceShip = new SpaceShip(shipID, shipName, new Point2D(x, y));
				}else {
					System.out.println("No match");
				}
				// Add to Planet ArrayList
				ships.add(currentSpaceShip);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return ships;
	}
	
	/* TODO: JavaDoc */
	public static ArrayList<Planet> readPlanet(File filename){
		ArrayList<Planet> planets = new ArrayList<Planet>();
		Scanner sc = null;
		try {
			sc = new Scanner(filename);
			// File Format -> Planet Color x y radius(size)
			// Pattern for Planet [A-Z][a-z]*\s[A-Z][a-z]*\s\d{2,4}\s\d{2,3}\s\d{2,3}
			final Pattern planetPattern = Pattern.compile("[A-Z][a-z]*\\s[A-Z][a-z]*\\s\\d{2,4}\\s\\d{2,3}\\s\\d{2,3}");
			// Ship to be processed/read from file 
			Planet currentPlanet = null;
			// Read file
			while (sc.hasNextLine())
			{
				// Read the line
				String currentLine = sc.nextLine();
				// Create matchers from patterns to compare with
				Matcher planetMatcher = planetPattern.matcher(currentLine);
				// Test if pattern matches with matcher
				if(planetMatcher.matches()) {
					StringTokenizer planetTokens = new StringTokenizer(currentLine, " ");
					String planetName = planetTokens.nextToken();
					String planetColor = planetTokens.nextToken();
					//Color color = planetColor.
					int x = Integer.parseInt(planetTokens.nextToken());
					int y = Integer.parseInt(planetTokens.nextToken());
					int radius = Integer.parseInt(planetTokens.nextToken());
					
					currentPlanet = new Planet(planetName, x, y, radius, Color.web(planetColor));
				}
				// Add to Planet ArrayList
				planets.add(currentPlanet);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return planets;
	}
}
