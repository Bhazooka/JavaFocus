/**
 * 
 */
package acsse.csc2a.model;

/**
 * @author Mr D Ogwok
 */
public interface IDrawVisitor {
	public void draw(SpaceShip s);
	public void draw(Planet p);
}
