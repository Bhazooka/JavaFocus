/**
 * 
 */
package acsse.csc2a.model;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;

/**
 * @author danielo
 *
 */
public class Planet implements IDrawable{
	private String name;
	private Point2D point;
	private Color color;
	private int radius;
	
	public Planet(String name, int x, int y, int radius, Color color){
		this.point = new Point2D(x, y);
		// this.point.setX(x);
		// this.point.setY(y);
		this.color = color;
		this.radius = radius;
		this.name = name;
	}

	/**
	 * @return the point
	 */
	public Point2D getPoint() {
		return point;
	}

	/**
	 * @param point the point to set
	 */
	public void setPoint(Point2D point) {
		this.point = point;
	}

	/**
	 * @return the color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public void accept(IDrawVisitor visitor) {
		visitor.draw(this);
	}

	/**
	 * @return the radius
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * @param radius the radius to set
	 */
	public void setRadius(int radius) {
		this.radius = radius;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}
