/**
 * 
 */
package acsse.csc2a.model;

/**
 * @author Mr D Ogwok
 * @version P06
 */
public interface IDrawable {
	public void accept(IDrawVisitor visitor); 
}
