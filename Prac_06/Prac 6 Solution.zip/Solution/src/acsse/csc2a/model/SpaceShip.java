package acsse.csc2a.model;
/**
 * 
 */

import javafx.geometry.Point2D;

/**
 * @author danielo
 *
 */
public class SpaceShip extends Ship implements IDrawable{
	
	private Point2D shipPosition;

	public SpaceShip(String iD, String name, Point2D pos) {
		super(iD, name);
		this.shipPosition = pos;
	}

	/**
	 * @return the shipPosition
	 */
	public Point2D getShipPosition() {
		return shipPosition;
	}

	/**
	 * @param shipPosition the shipPosition to set
	 */
	public void setShipPosition(Point2D shipPosition) {
		this.shipPosition = shipPosition;
	}

	@Override
	public void accept(IDrawVisitor visitor) {
		visitor.draw(this);
	}
	
}
