/**
 * 
 */
package acsse.csc2a.gui;

import acsse.csc2a.model.IDrawVisitor;
import acsse.csc2a.model.Planet;
import acsse.csc2a.model.SpaceShip;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * @author Mr D Ogwok
 * @version P06
 */
public class DrawVisitor implements IDrawVisitor{
	
	/* TODO: JavaDoc */
	private GraphicsContext	gc;
	public static final int	DEFAULT_SIZE = 100;

	/* TODO: JavaDoc */
	public GraphicsContext getGraphicsContext()
	{
		return gc;
	}

	/* TODO: JavaDoc */
	public void setGraphicsContext(GraphicsContext gc)
	{
		this.gc = gc;
	}

	/* TODO: JavaDoc */
	@Override
	public void draw(SpaceShip s) {
		// Draw SpaceShip
		gc.setFill(Color.GREEN);
		gc.fillRect(s.getShipPosition().getX(), s.getShipPosition().getY(), 100, 30);
		// Add SpaceShip Details
		gc.setStroke(Color.WHITESMOKE);
		gc.strokeText(s.getName(), s.getShipPosition().getX(), s.getShipPosition().getY() + 20);
	}

	/* TODO: JavaDoc */
	@Override
	public void draw(Planet p) {
		// Draw Planet
		gc.setFill(p.getColor());
		gc.fillOval(p.getPoint().getX(), p.getPoint().getY(), p.getRadius(), p.getRadius());
		// Add Planet Name
		gc.setStroke(Color.WHITE);
		gc.strokeText(p.getName(), (p.getPoint().getX()  + (0.25 * p.getRadius())), (p.getPoint().getY() + (0.5 * p.getRadius())));
	}

}
