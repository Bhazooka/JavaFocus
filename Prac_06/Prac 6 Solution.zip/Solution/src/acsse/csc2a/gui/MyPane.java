/**
 * 
 */
package acsse.csc2a.gui;

import java.io.File;
import java.util.ArrayList;

import acsse.csc2a.file.FileIO;
import acsse.csc2a.model.Planet;
import acsse.csc2a.model.SpaceShip;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;

/**
 * @author Mr D Ogwok
 * @version P06
 */
public class MyPane extends StackPane{
	
	/* TODO: JavaDoc */
	MyCanvas canvas = new MyCanvas();
	ArrayList<Planet> planets = null;
	ArrayList<SpaceShip> ships = null;
	
	/* TODO: JavaDoc */
	public MyPane() {
		// Initialize ArrayLists
		planets = new ArrayList<Planet>();
		ships = new ArrayList<SpaceShip>();
		// Set the Canvas
		// canvas.widthProperty().bind(this.widthProperty());
		canvas.setWidth(1500);
		canvas.setHeight(500);
		
		// Create MenuBar
		MenuBar menuBar = createMenuBar();
		
		// Add to layout
		VBox layout = new VBox();
		layout.getChildren().addAll(menuBar, canvas);
		this.getChildren().add(layout);
	}
	
	/* TODO: JavaDoc */
	private MenuBar createMenuBar() {
		MenuBar menuBar = new MenuBar();
		Menu menu = new Menu("File");
		menuBar.getMenus().add(menu);
		MenuItem mi1 = new MenuItem("Open Planets");
		MenuItem mi2 = new MenuItem("Open Space Ships");
		menu.getItems().addAll(mi1, mi2);
		//Add action Listener for first button
		mi1.setOnAction(e -> {
			//Open File Chooser
			final FileChooser fc = new FileChooser();
			fc.setTitle("Choose File");
			fc.setInitialDirectory(new File("./data"));
			File file = fc.showOpenDialog(null);
			if(file != null) {
				// Set canvas data after reading from file
				planets = FileIO.readPlanet(file);
				setPlanets(planets);
			}
		});
		//Add action Listener for second button
		mi2.setOnAction(e -> {
			//Open File Chooser
			final FileChooser fc = new FileChooser();
			fc.setTitle("Choose File");
			fc.setInitialDirectory(new File("./data"));
			File file = fc.showOpenDialog(null);
			if(file != null) {
				// Set canvas data after reading from file
				this.ships = FileIO.readSpaceShip(file);
				setSpaceShips(this.ships);
			}
		});
		return menuBar;
	}
	
	/* TODO: JavaDoc */
	private void setSpaceShips(ArrayList<SpaceShip> ships)
	{
		 canvas.setSpaceShips(ships);
	}
	
	/* TODO: JavaDoc */
	private void setPlanets(ArrayList<Planet> planets)
	{
		canvas.setPlanets(planets);
	}
	
}
