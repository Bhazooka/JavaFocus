/**
 * 
 */
package acsse.csc2a.gui;

import java.util.ArrayList;

import acsse.csc2a.model.Planet;
import acsse.csc2a.model.SpaceShip;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * @author Mr D Ogwok
 * @version P06
 */
public class MyCanvas extends Canvas{
	
	// ArrayList of Items
	private ArrayList<Planet> planets = null;
	private ArrayList<SpaceShip> ships = null;
	private DrawVisitor visitor = null;
	
	/* TODO: JavaDoc */
	public MyCanvas() {
		this.visitor = new DrawVisitor();
		planets = new ArrayList<Planet>();
		ships = new ArrayList<SpaceShip>();
	}
	
	/* TODO: JavaDoc */
	public void setPlanets(ArrayList<Planet> planets) {
		this.planets = planets;
		repaintCanvas();
	}
	
	/* TODO: JavaDoc */
	public void setSpaceShips(ArrayList<SpaceShip> ships) {
		this.ships = ships;
		repaintCanvas();
	}
	
	/* TODO: JavaDoc */
	public void repaintCanvas() {
		// Get the Graphics Context
		GraphicsContext gc = this.getGraphicsContext2D();
		// Clear the Canvas
		gc.setFill(Color.WHITE);
		gc.fillRect(0, 0, this.getWidth(), this.getHeight());
		//Hand over graphics context to the Visitor to draw
		visitor.setGraphicsContext(gc);
		
		// Send the visitor to draw everything
		for(Planet p: planets) {
			p.accept(visitor);
		}
		for(SpaceShip s: this.ships) {
			s.accept(visitor);
		}
	}
}
