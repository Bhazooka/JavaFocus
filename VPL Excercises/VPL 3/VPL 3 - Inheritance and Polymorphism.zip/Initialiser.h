#ifndef INITIALISER_H
#define INITIALISER_H

class UJList;

class Initialiser
{
public:
    virtual void initialise(UJList& objList) = 0;
};

#endif