#include "CompositeInitialiser.h"

void CompositeInitialiser::initialise(UJList& objList)
{
    objList.add(0,4);
    objList.add(1,6);
    objList.add(2,8);
    objList.add(3,9);
    objList.add(4,10);
    objList.add(5,12);
    objList.add(6,14);
    objList.add(7,15);
    objList.add(8,16);
    objList.add(9,18);
    objList.add(10,20);
    objList.add(11,21);
    objList.add(12,22);
    objList.add(13,24);
    objList.add(14,25);
    objList.add(15,26);
    objList.add(16,27);
    objList.add(17,28);
    objList.add(18,30);
    objList.add(19,32);
}