#ifndef PRIMEINITIALISER_H
#define PRIMEINITIALISER_H

#include "UJList.h"
#include"Initialiser.h"

class UJList;
class PrimeInitialiser: public Initialiser
{
    public:
     virtual void  initialise(UJList& objList);
    
 private:
 
 
};

#endif