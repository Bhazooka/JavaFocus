#include "PrimeInitialiser.h"
#include "UJList.h"
#include <cmath>



void PrimeInitialiser :: initialise(UJList& objList)
{
    bool isPrime = true;
    int count = 2;
    
   while(count < 100)
    {
        if (count == 2 || count == 3)
        {
           isPrime = true;
        }
        
       for (int i = 2; i <= sqrt(count); i++)
       {
            if (count % i == 0)
            {
               isPrime = false;
            }
       }
        
        if(isPrime)
        {
             objList.add(count);
        }
        //reset prime
        isPrime = true;
        count++;
    }
}