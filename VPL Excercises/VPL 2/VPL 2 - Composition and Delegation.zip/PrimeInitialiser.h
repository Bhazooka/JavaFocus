#ifndef PRIMEINITIALISER_H_INCLUDED
#define PRIMEINITIALISER_H_INCLUDED


class UJList;

class PrimeInitialiser
{
public:
    //Constructor
    //PrimeInitialiser();
    
    //Method
    void initialise(UJList& objList);
};

#endif //PRIMEINITIALISER_H_INCLUDED