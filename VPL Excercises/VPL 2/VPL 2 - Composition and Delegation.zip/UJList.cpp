#include "UJList.h"
#include "PrimeInitialiser.h"

 //constructors
    UJList :: UJList() : UJList(DEFAULT_LENGTH, DEFAULT_VALUE)
    {
        
    }
    
    UJList :: UJList(int intLength, int intValue)
    {
        alloc(intLength, intValue);
    }
    UJList :: UJList(const UJList& objOriginal)
    {
        clone(objOriginal);
    }
    
    //destructor
    UJList :: ~UJList()
    {
        dealloc();
    }
    
    //Member Functions
    //Accessor methods
    int UJList :: get(int intIndex) const
    {
        return _List[intIndex];
    }
    
    int UJList :: length() const
    {
        return _Length;
    }
    
    //Mutator methods
    void UJList :: add(int intValue)
    {
        if( _index < length())
        {
            _List[_index] = intValue;
            _index++ ;
        }
    }
    
    void UJList :: initialise()
    {
        _Prime -> initialise(*this); //Delegation
    }
    
    //Utility Functions
    void UJList :: alloc(int intLength, int intValue)
    {
        _Length = intLength;
        _Value = intValue;
        _index=0;
        _List = new int[_Length];
        _Prime = new PrimeInitialiser;
        for(int l = 0; l < _Length; l++)
        {
            _List[l] = _Value;
        }
    }
    
    void UJList :: dealloc()
    {
        delete _List;
        delete _Prime;
    }
    
    void UJList :: clone(const UJList& objOriginal)
    {
        for (int p = 0;  p < _Length; p++)
        {
            _List[p] = objOriginal._List[p];
        }
    }