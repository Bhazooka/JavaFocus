#ifndef UJLIST_H_INCLUDED
#define UJLIST_H_INCLUDED


  enum ProgramStatus
  {
      SUCESS
  };

class PrimeInitialiser;  

class UJList
{
public:
    //constructors
    UJList();
    UJList(int intLength, int intValue);
    UJList(const UJList& objOriginal);
    
    //destructor
    ~UJList();
    
    //Member Functions
    //Accessor methods
    int get(int intIndex) const;
    int length() const;
    
    //Mutator methods
    void add(int intValue);
    void initialise();
    
    //Constants
    static const int DEFAULT_LENGTH = 14;
    static const int DEFAULT_VALUE = 5;

private:
    //Utility Functions
    void alloc(int intLength, int intValue);
    void dealloc();
    void clone(const UJList& objOriginal);
    
    //Member Variables
    int _Length;
    int _Value;
    int _index;
    int* _List;
    PrimeInitialiser* _Prime; //Lifestyle Management
};

#endif // UJLIST_H_INCLUDED