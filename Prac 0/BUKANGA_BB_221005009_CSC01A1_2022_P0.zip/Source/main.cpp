#include <iostream> //this is a library for c++ (prewritten code)

using namespace std;

int main()
{
    string strEveSecret = "Cast " ; 
    string strDiscordSecret = "Conditional" ;
    string strVPLSecret = "algorithm";
    string strRecording = "Recursion";
    string strStudentnbr = "221005009";
    
    
    cout << strEveSecret << '\n';
    cout << strDiscordSecret << '\n';
    cout << strVPLSecret << '\n';
    cout << strRecording << '\n';
    cout << strStudentnbr;
    
    //you can also just write the code as:
    // cout << strEveSecret << endl << cout << strDiscordSecret << endl << cout << strVPLSecret;
    // but we wont do that for readability
    
    return 0;
}