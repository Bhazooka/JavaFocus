import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

/**
 * @author barbu
 * Public Class FileIO
 */
public class FileIO {
	/**
	 * @param file
	 * @return Object
	 * Static Method
	 */
	public static ArrayList<Transmitter> readFile(File file){
		//Arraylist of Transitter object
		ArrayList<Transmitter> transmittersList = new ArrayList<Transmitter>();;
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));)
		{
			//For loop to read through and add each object
			int ListSize = ois.readInt();
			for(int i = 0 ; i < ListSize ; i++)
			{
				//casting to intended type
				transmittersList.add((Transmitter)ois.readObject());	
			}
		}
		catch(IOException e){
			e.printStackTrace();
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		return transmittersList;
	}

}
