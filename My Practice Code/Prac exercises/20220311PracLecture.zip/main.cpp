#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

void optionA();
void optionC();
void pause();
int fibonacci(int intPrev1, int intPrev2);
void transform(int intX, int intY, int intLimit, int& intX1, int& intX2);

int main()
{
    //The menu option must be displayed every time an option is completed.  That means the whole menu needs to be repeated.
    //We will use a bool variable to inform us to break out of the repetition.
    bool blnContinue = true;
    char chInput = '\0';
    
    //The do-while loop will execute everything at least once.  After executing everything at least once, the while-statement is evaluated.
    do
    {
        //Clear the screen
        system("clear");        //If using CodeBlocks use the Windows equavalent system("cls");
        //Display a menu
        cout << "A) Fibonnaci series" << endl
             << "B) ASCII values" << endl
             << "C) Create two new coordinates" << endl
             << "X) Exit the program" << endl;
        cin >> chInput;
        
        switch(chInput)
        {
            case 'a':
            case 'A':
            {
                optionA();
                break;
            }
            case 'b':
            case 'B':
            {
                string strSentence;
                cout << "Please type a sentence and press Enter:" << endl;
                cin.ignore(100,'\n');
                getline(cin,strSentence);
                for(char c: strSentence)
                {
                    cout << c << ":" << static_cast<int>(c) << endl;
                }
                
                //Pause
                cout << "Press Enter to continue" << endl;
                cin.get();
                break;
            }
            case 'c':
            case 'C':
            {
                optionC();
                break;
            }
            case 'x':
            case 'X':
            {
                blnContinue = false;
                break;
            }
            default:
            {
                cerr << "Please type in a valid menu option" << endl;
                cerr << "Press Enter to continue" << endl;
                cin.ignore(100,'\n');
                cin.get();
            }
        }
        
    }while(blnContinue);    //Loop back to do while the statement evaluates to true
    
    return 0;
}

void optionA()
{
    //Variables to be used in Fibonnaci
    int intN = 0;
    int intN1 = 1;
    int intN0 = 0;
    int intTemp = 0;
    //Get the number of Fibonacci terms.
    cout << "How many Fibonacci numbers do you want to display (>2):";
    cin >> intN;
    while(cin.fail())
    {
        string strRubbish;
        cin >> strRubbish;
        cin.clear();
        cout << "How many Fibonacci numbers do you want to display (>2):";
        cin >> intN;
    }
    
    if(intN <= 2)
    {
        cerr << "Please ensure you specify more than three terms.  Please select from the main menu again." << endl;
        cerr << "Press Enter to continue" << endl;
        cin.ignore(100,'\n');
        cin.get();
        return;
    }
    
    //Output the results.  Always output the first two terms
    cout << "0 1";
    for(int n=2;n<intN;n++)
    {
        intTemp = fibonacci(intN1,intN0);
        cout << " " << intTemp;
        intN0 = intN1;
        intN1 = intTemp;
    }
    cout << endl;
    
    //Pause
    cerr << "Press Enter to continue" << endl;
    cin.ignore(100,'\n');
    cin.get();
}

int fibonacci(int intPrev1, int intPrev2)
{
    int intNum = 0;
    intNum = intPrev1 + intPrev2;
    return intNum;
}

void optionC()
{
    int intX = 0;
    int intY = 0;
    int intLimit = 0;
    int intX1 = 0;
    int intY1 = 0;
    
    cout << "Please type in X:";
    cin >> intX;
    cout << "Please type in Y:";
    cin >> intY;
    cout << "Please type in a limit >(X and Y):";
    cin >> intLimit;
    transform(intX,intY,intLimit,intX1,intY1);
    cout << "The new X-coordinate is:" << intX1 << endl;
    cout << "The new Y-coordinate is:" << intY1 << endl;
    cout << "The original X-coordate was:" << intX << endl;
    cout << "The original Y-coordate was:" << intY << endl;
    
    pause();
}

void transform(int intX, int intY, int intLimit, int& intX1, int& intY1)
{
    intX1 = abs(intX - intLimit);
    intY1 = abs(intY - intLimit);
    intX = 99;
    intY = 1000;
}

void pause()
{
    //Pause
    cerr << "Press Enter to continue" << endl;
    cin.ignore(100,'\n');
    cin.get();
}







