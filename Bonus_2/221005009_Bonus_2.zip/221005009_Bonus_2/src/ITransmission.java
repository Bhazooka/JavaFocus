import model.Ship;

/**
 * @author barbu
 * ITransmission interface
 */
public interface ITransmission {
	public Ship getShip(String shipData);
}
