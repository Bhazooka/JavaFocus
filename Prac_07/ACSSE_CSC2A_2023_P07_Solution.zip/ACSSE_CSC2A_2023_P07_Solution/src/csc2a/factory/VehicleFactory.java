package csc2a.factory;

import csc2a.models.rover.E_PLANET;
import csc2a.models.rover.RoverVehicle;
import csc2a.models.spaceship.SpaceshipVehicle;

/* TODO: JavaDoc */
public interface VehicleFactory {
	RoverVehicle createRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts);
	SpaceshipVehicle createSpaceship(String type, boolean manned);
}
