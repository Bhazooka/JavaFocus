/**
 * 
 */
package csc2a.factory;

import csc2a.models.rover.E_PLANET;
import csc2a.models.rover.EarthTraveller;
import csc2a.models.rover.MarsRover;
import csc2a.models.rover.MercuryExplorationRover;
import csc2a.models.rover.RoverVehicle;
import csc2a.models.rover.VenusPathfinder;
import csc2a.models.spaceship.Atmospheric;
import csc2a.models.spaceship.Orbiter;
import csc2a.models.spaceship.Passenger;
import csc2a.models.spaceship.RoverCarrier;
import csc2a.models.spaceship.SpaceshipVehicle;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class CivilianFactory implements VehicleFactory{

	/* TODO: JavaDoc */
	@Override
	public RoverVehicle createRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		// Civilian -> No Armour Plating, No Weapon Mounts 
		if(planet.equals(E_PLANET.Mars)) {
			return new MarsRover(planet, hasArmourPlating, hasWeaponMounts);
		}else if(planet.equals(E_PLANET.Earth)) {
			return new EarthTraveller(planet, hasArmourPlating, hasWeaponMounts);
		}else if(planet.equals(E_PLANET.Mercury)) {
			return new MercuryExplorationRover(planet, hasArmourPlating, hasWeaponMounts);
		}else if(planet.equals(E_PLANET.Venus)) {
			return new VenusPathfinder(planet, hasArmourPlating, hasWeaponMounts);
		}else {
			return null;
		}
	}

	/* TODO: JavaDoc */
	@Override
	public SpaceshipVehicle createSpaceship(String type, boolean manned) {
		// Civilian unmanned -> Only creates Passenger
		if(type.equals("Atmospheric")) {
			return new Atmospheric(manned);
		}else if(type.equals("Orbiter")) {
			return new Orbiter(manned);
		}else if(type.equals("Passenger")) {
			return new Passenger(manned);
		}else if(type.equals("RoverCarrier")) {
			return new RoverCarrier(manned);
		}else {
			return null;
		}
		
	}

}
