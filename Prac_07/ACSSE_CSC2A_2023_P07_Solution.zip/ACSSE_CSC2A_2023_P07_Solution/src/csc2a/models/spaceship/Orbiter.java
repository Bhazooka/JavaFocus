package csc2a.models.spaceship;

import csc2a.models.rover.E_PLANET;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class Orbiter extends Spaceship{
	/* TODO: JavaDoc */
	private E_PLANET planet;
	
	/* TODO: JavaDoc */
	public Orbiter(boolean manned) {
		super(manned);
	}

	/* TODO: JavaDoc */
	public E_PLANET getPlanet() {
		return planet;
	}

	/* TODO: JavaDoc */
	public void setPlanet(E_PLANET planet) {
		this.planet = planet;
	}

	/* TODO: JavaDoc */
	@Override
	public void fly() {
		System.out.println("Flying Orbiter Spaceship with around Planet " + planet);
	}
	
}
