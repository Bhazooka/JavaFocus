package csc2a.models.spaceship;

/**
 * @author Mr D Ogwok
 * @version P07
 */

public abstract class Spaceship implements SpaceshipVehicle{
	/* TODO: JavaDoc */
	private boolean manned;

	/* TODO: JavaDoc */
	public Spaceship(boolean manned) {
		this.manned = manned;
	}

	/* TODO: JavaDoc */
	public boolean isManned() {
		return manned;
	}

}
