package csc2a.models.spaceship;

import csc2a.models.rover.E_PLANET;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class Atmospheric extends Spaceship{
	/* TODO: JavaDoc */
	private int numSensors;
	private E_PLANET planet;

	/* TODO: JavaDoc */
	public Atmospheric(boolean manned) {
		super(manned);
	}

	/* TODO: JavaDoc */
	public int getNumSensors() {
		return numSensors;
	}

	/* TODO: JavaDoc */
	public void setNumSensors(int numSensors) {
		this.numSensors = numSensors;
	}

	/* TODO: JavaDoc */
	public E_PLANET getPlanet() {
		return planet;
	}

	/* TODO: JavaDoc */
	public void setPlanet(E_PLANET planet) {
		this.planet = planet;
	}

	/* TODO: JavaDoc */
	@Override
	public void fly() {
		System.out.println("Flying Atmospheric Spaceship with " + numSensors + " sensors around Planet " + planet);
	}
}
