package csc2a.models.spaceship;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class Passenger extends Spaceship{
	/* TODO: JavaDoc */
	private int numPassengers;
	
	/* TODO: JavaDoc */
	public Passenger(boolean manned) {
		super(manned);
	}

	/* TODO: JavaDoc */
	public int getNumPassengers() {
		return numPassengers;
	}

	/* TODO: JavaDoc */
	public void setNumPassengers(int numPassengers) {
		this.numPassengers = numPassengers;
	}

	/* TODO: JavaDoc */
	@Override
	public void fly() {
		System.out.println("Flying Passenger Spaceship with " + numPassengers + " passengers.");
	}

}
