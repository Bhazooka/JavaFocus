package csc2a.models.spaceship;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public interface SpaceshipVehicle {
	void fly();
}
