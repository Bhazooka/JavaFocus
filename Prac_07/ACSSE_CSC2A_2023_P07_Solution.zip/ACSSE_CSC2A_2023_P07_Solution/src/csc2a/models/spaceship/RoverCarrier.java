package csc2a.models.spaceship;

import java.util.ArrayList;

import csc2a.models.rover.Rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class RoverCarrier extends Spaceship{
	/* TODO: JavaDoc */
	private ArrayList<Rover> rovers;

	/* TODO: JavaDoc */
	public RoverCarrier(boolean manned) {
		super(manned);
	}

	/* TODO: JavaDoc */
	public ArrayList<Rover> getRovers() {
		return rovers;
	}
	
	/* TODO: JavaDoc */
	public Rover getRover(int roverID) {
		return rovers.get(roverID);
	}

	/* TODO: JavaDoc */
	public void setRovers(ArrayList<Rover> rovers) {
		this.rovers = rovers;
	}

	/* TODO: JavaDoc */
	@Override
	public void fly() {
		System.out.println("Flying RoverCarrier Spaceship with " + rovers.size() + " Rovers.");
	}
}
