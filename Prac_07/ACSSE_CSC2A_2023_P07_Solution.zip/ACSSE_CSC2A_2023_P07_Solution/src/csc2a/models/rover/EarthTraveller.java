package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class EarthTraveller extends Rover{
	/* TODO: JavaDoc */
	private int ATVClass;
	
	/* TODO: JavaDoc */
	public EarthTraveller(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		super(planet, hasArmourPlating, hasWeaponMounts);
	}

	/* TODO: JavaDoc */
	public int getATVClass() {
		return ATVClass;
	}

	/* TODO: JavaDoc */
	public void setATVClass(int aTVClass) {
		ATVClass = aTVClass;
	}

	/* TODO: JavaDoc */
	@Override
	public void drive() {
		System.out.println("Driving Earth Traveller Rover of class" + ATVClass);
	}
	
}
