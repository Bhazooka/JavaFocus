package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class VenusPathfinder extends Rover{
	/* TODO: JavaDoc */
	private double atmosphericPressure;
	private int temp;
	
	/* TODO: JavaDoc */
	public VenusPathfinder(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		super(planet, hasArmourPlating, hasWeaponMounts);
	}

	/* TODO: JavaDoc */
	public double getAtmosphericPressure() {
		return atmosphericPressure;
	}

	/* TODO: JavaDoc */
	public void setAtmosphericPressure(double atmosphericPressure) {
		this.atmosphericPressure = atmosphericPressure;
	}

	/* TODO: JavaDoc */
	public int getTemp() {
		return temp;
	}

	/* TODO: JavaDoc */
	public void setTemp(int temp) {
		this.temp = temp;
	}

	/* TODO: JavaDoc */
	@Override
	public void drive() {
		System.out.println("Driving Vanus Pathfinder Rover with temperature recording at " + temp + " degrees and " + atmosphericPressure + " atmospheric Pressure reading.");
	}

}
