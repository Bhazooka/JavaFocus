package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class MarsRover extends Rover{
	/* TODO: JavaDoc */
	private int numWheels;
	private int numArms;

	/* TODO: JavaDoc */
	public MarsRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		super(planet, hasArmourPlating, hasWeaponMounts);
	}

	/* TODO: JavaDoc */
	public int getNumWheels() {
		return numWheels;
	}

	/* TODO: JavaDoc */
	public void setNumWheels(int numWheels) {
		this.numWheels = numWheels;
	}

	/* TODO: JavaDoc */
	public int getNumArms() {
		return numArms;
	}

	/* TODO: JavaDoc */
	public void setNumArms(int numArms) {
		this.numArms = numArms;
	}

	/* TODO: JavaDoc */
	@Override
	public void drive() {
		System.out.println("Driving Mars Rover with " + numWheels + " wheels and " + numArms + " arms.");
	}
	
}
