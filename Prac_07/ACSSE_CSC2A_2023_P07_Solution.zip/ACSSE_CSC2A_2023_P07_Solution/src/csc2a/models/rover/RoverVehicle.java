package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public interface RoverVehicle {
	void drive();
}
