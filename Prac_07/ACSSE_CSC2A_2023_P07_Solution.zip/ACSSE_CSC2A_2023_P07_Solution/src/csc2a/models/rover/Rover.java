package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public abstract class Rover implements RoverVehicle{
	/* TODO: JavaDoc */
	private E_PLANET planet;
	private boolean hasWeaponMounts;
	private boolean hasArmourPlating;

	/* TODO: JavaDoc */
	public Rover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		this.planet = planet;
		this.hasWeaponMounts = hasWeaponMounts;
		this.hasArmourPlating = hasArmourPlating;
	}

	/* TODO: JavaDoc */
	public E_PLANET getPlanet() {
		return planet;
	}

	/* TODO: JavaDoc */
	public boolean isHasWeaponMounts() {
		return hasWeaponMounts;
	}

	/* TODO: JavaDoc */
	public void setHasWeaponMounts(boolean hasWeaponMounts) {
		this.hasWeaponMounts = hasWeaponMounts;
	}

	/* TODO: JavaDoc */
	public boolean isHasArmourPlating() {
		return hasArmourPlating;
	}

	/* TODO: JavaDoc */
	public void setHasArmourPlating(boolean hasArmourPlating) {
		this.hasArmourPlating = hasArmourPlating;
	}
	
}
