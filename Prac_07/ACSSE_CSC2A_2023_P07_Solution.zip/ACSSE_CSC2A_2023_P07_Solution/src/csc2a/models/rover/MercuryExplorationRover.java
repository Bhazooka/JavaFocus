package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public class MercuryExplorationRover extends Rover{
	/* TODO: JavaDoc */
	private int temp;
	private int numMinerals;
	
	/* TODO: JavaDoc */
	public MercuryExplorationRover(E_PLANET planet, boolean hasArmourPlating, boolean hasWeaponMounts) {
		super(planet, hasArmourPlating, hasWeaponMounts);
	}

	/* TODO: JavaDoc */
	public int getTemp() {
		return temp;
	}

	/* TODO: JavaDoc */
	public void setTemp(int temp) {
		this.temp = temp;
	}

	/* TODO: JavaDoc */
	public int getNumMinerals() {
		return numMinerals;
	}

	/* TODO: JavaDoc */
	public void setNumMinerals(int numMinerals) {
		this.numMinerals = numMinerals;
	}

	/* TODO: JavaDoc */
	@Override
	public void drive() {
		System.out.println("Driving Mercury Exploration Rover with temperature recording at " + temp + " degrees and upto " + numMinerals + " minerals can be recorded.");
	}	
}
