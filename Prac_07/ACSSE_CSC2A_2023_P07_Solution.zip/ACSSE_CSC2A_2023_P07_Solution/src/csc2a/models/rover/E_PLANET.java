package csc2a.models.rover;

/**
 * @author Mr D Ogwok
 * @version P07
 */
public enum E_PLANET {
	Earth,
	Mars,
	Mercury,
	Venus
}
